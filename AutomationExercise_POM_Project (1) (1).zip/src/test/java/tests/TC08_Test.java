package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC08_Test extends BaseTest {

    @Test
    public void testCase08() {
        // TODO: Implement test steps for TC08
        Assert.assertTrue(true, "Test Case 8 passed.");
    }
}
