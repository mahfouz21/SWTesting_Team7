package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC26_Test extends BaseTest {

    @Test
    public void testCase26() {
        // TODO: Implement test steps for TC26
        Assert.assertTrue(true, "Test Case 26 passed.");
    }
}
