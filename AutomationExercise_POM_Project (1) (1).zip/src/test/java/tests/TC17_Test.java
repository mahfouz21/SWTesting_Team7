package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC17_Test extends BaseTest {

    @Test
    public void testCase17() {
        // TODO: Implement test steps for TC17
        Assert.assertTrue(true, "Test Case 17 passed.");
    }
}
