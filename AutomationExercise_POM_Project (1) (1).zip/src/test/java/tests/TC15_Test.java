package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC15_Test extends BaseTest {

    @Test
    public void testCase15() {
        // TODO: Implement test steps for TC15
        Assert.assertTrue(true, "Test Case 15 passed.");
    }
}
