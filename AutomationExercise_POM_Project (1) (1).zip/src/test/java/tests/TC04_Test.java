package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC04_Test extends BaseTest {

    @Test
    public void testCase04() {
        // TODO: Implement test steps for TC04
        Assert.assertTrue(true, "Test Case 4 passed.");
    }
}
