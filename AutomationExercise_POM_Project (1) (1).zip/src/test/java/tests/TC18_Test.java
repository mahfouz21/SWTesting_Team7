package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC18_Test extends BaseTest {

    @Test
    public void testCase18() {
        // TODO: Implement test steps for TC18
        Assert.assertTrue(true, "Test Case 18 passed.");
    }
}
