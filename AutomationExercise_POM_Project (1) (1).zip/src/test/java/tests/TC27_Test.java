package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC27_Test extends BaseTest {

    @Test
    public void testCase27() {
        // TODO: Implement test steps for TC27
        Assert.assertTrue(true, "Test Case 27 passed.");
    }
}
