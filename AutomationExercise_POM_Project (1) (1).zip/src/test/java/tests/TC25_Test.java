package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC25_Test extends BaseTest {

    @Test
    public void testCase25() {
        // TODO: Implement test steps for TC25
        Assert.assertTrue(true, "Test Case 25 passed.");
    }
}
