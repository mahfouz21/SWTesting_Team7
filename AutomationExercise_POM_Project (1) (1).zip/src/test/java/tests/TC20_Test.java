package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC20_Test extends BaseTest {

    @Test
    public void testCase20() {
        // TODO: Implement test steps for TC20
        Assert.assertTrue(true, "Test Case 20 passed.");
    }
}
