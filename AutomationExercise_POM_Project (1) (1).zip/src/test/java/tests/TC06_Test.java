package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC06_Test extends BaseTest {

    @Test
    public void testCase06() {
        // TODO: Implement test steps for TC06
        Assert.assertTrue(true, "Test Case 6 passed.");
    }
}
