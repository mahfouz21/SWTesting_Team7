package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC05_Test extends BaseTest {

    @Test
    public void testCase05() {
        // TODO: Implement test steps for TC05
        Assert.assertTrue(true, "Test Case 5 passed.");
    }
}
