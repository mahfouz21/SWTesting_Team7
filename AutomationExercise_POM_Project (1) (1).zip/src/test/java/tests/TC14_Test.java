package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC14_Test extends BaseTest {

    @Test
    public void testCase14() {
        // TODO: Implement test steps for TC14
        Assert.assertTrue(true, "Test Case 14 passed.");
    }
}
