package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC13_Test extends BaseTest {

    @Test
    public void testCase13() {
        // TODO: Implement test steps for TC13
        Assert.assertTrue(true, "Test Case 13 passed.");
    }
}
