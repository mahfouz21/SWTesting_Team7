package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC09_Test extends BaseTest {

    @Test
    public void testCase09() {
        // TODO: Implement test steps for TC09
        Assert.assertTrue(true, "Test Case 9 passed.");
    }
}
