package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC10_Test extends BaseTest {

    @Test
    public void testCase10() {
        // TODO: Implement test steps for TC10
        Assert.assertTrue(true, "Test Case 10 passed.");
    }
}
