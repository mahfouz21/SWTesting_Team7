package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC02_Test extends BaseTest {

    @Test
    public void testCase02() {
        // TODO: Implement test steps for TC02
        Assert.assertTrue(true, "Test Case 2 passed.");
    }
}
