package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC23_Test extends BaseTest {

    @Test
    public void testCase23() {
        // TODO: Implement test steps for TC23
        Assert.assertTrue(true, "Test Case 23 passed.");
    }
}
