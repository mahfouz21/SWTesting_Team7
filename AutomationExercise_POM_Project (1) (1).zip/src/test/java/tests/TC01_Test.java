package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC01_Test extends BaseTest {

    @Test
    public void testCase01() {
        // TODO: Implement test steps for TC01
        Assert.assertTrue(true, "Test Case 1 passed.");
    }
}
