package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC03_Test extends BaseTest {

    @Test
    public void testCase03() {
        // TODO: Implement test steps for TC03
        Assert.assertTrue(true, "Test Case 3 passed.");
    }
}
