package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC21_Test extends BaseTest {

    @Test
    public void testCase21() {
        // TODO: Implement test steps for TC21
        Assert.assertTrue(true, "Test Case 21 passed.");
    }
}
